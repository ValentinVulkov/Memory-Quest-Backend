import { useEffect, useState } from "react";
import TopBar from "./components/TopBar";
import DecksView from "./components/DecksView";
import AuthModal from "./components/AuthModal";
import { loginUser, registerUser, fetchDecks, createDeck } from "./api";

export default function App() {
    const [token, setToken] = useState(localStorage.getItem("token") || "");
    const [authOk, setAuthOk] = useState(false);
    const [decks, setDecks] = useState([]);

    const [authOpen, setAuthOpen] = useState(false);
    const [mode, setMode] = useState("login");

    const [username, setUsername] = useState("");
    const [email, setEmail] = useState("v@v.com");
    const [password, setPassword] = useState("123456");
    const [showPassword, setShowPassword] = useState(false);

    const [deckTitle, setDeckTitle] = useState("");
    const [deckDescription, setDeckDescription] = useState("");

    useEffect(() => { if (!token) setAuthOpen(true); }, [token]);
    useEffect(() => { if (token) fetchDecks(token).then(d => { setDecks(d); setAuthOk(true); }); }, [token]);

    async function login(e) {
        e.preventDefault();
        const data = await loginUser(email, password);
        const t = data.token;
        localStorage.setItem("token", t);
        setToken(t);
        setAuthOpen(false);
    }

    async function register(e) {
        e.preventDefault();
        await registerUser(username, email, password);
        setMode("login");
    }

    async function addDeck(e) {
        e.preventDefault();
        await createDeck(token, deckTitle, deckDescription);
        setDeckTitle("");
        setDeckDescription("");
        const d = await fetchDecks(token);
        setDecks(d);
    }

    return (
        <div style={{ maxWidth: 900, margin: "40px auto" }}>
            <TopBar token={token} onOpenAuth={() => setAuthOpen(true)} onLogout={() => { localStorage.removeItem("token"); setToken(""); }} />

            <DecksView
                token={token}
                authOk={authOk}
                decks={decks}
                deckTitle={deckTitle}
                setDeckTitle={setDeckTitle}
                deckDescription={deckDescription}
                setDeckDescription={setDeckDescription}
                onCreateDeck={addDeck}
            />

            <AuthModal
                open={authOpen}
                token={token}
                mode={mode}
                setMode={setMode}
                username={username}
                setUsername={setUsername}
                email={email}
                setEmail={setEmail}
                password={password}
                setPassword={setPassword}
                showPassword={showPassword}
                setShowPassword={setShowPassword}
                onLogin={login}
                onRegister={register}
                onClose={() => setAuthOpen(false)}
            />
        </div>
    );
}
